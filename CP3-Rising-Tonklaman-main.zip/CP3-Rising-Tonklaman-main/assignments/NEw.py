diction = {'Rising':'ผงาด' ,'Hopper':'ตั๊กแตน','Metal':'โลหะ','Realize':'ตระหนัก','Blood':'เลือด'}
print('It is mean' , diction['Rising'])