s=input("Enter your distance:")
t=input("Enter your time:")
v=int(s)/int(t)
print(v, "km/hr")
