import math

n=int(input())
print('start')
def definE(n=0):
    while n >= 0:
        n += 1
        print('e=', (1 + 1 / n) ** n)
    return print('e=', (1 + 1 / n) ** n)

while
r**2+r**2-2r*r*math.cos(n/3)