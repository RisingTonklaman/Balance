English=100.0
Business=98.5
ComputerS =101.9
ComputerP = 100.1
print("Foundation English                  : ",English)
print("General Business                    : ",Business)
print("Introduction to Computer Systems    : ",ComputerS)
print("Computer Programming                : ",ComputerP)

