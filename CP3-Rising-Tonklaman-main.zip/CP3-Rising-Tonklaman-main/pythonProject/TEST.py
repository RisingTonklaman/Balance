Username=input("Enter your Username:")
Password=input("Enter your Username:")
while Username!="Tonkla" or Password!=str(123456) :
    print("Try again")
    Username = input("Enter your Username:")
    Password = input("Enter your Username:")
print("Success")