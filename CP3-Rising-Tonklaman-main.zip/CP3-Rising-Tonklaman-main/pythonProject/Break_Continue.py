for val in 'helloWorld':
        if val == 'l':
            break
        print(val)
print('-----------------------------------------------')
for val in 'helloWorld':
        if val == 'l':
            continue
        print(val)