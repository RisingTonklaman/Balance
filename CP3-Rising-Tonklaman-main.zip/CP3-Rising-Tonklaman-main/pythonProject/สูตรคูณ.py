x=2
y=1
for n in range(11) :
    for n in range(12):
        z=x*y
        print(x,"x",y,"=",z)
        y+=1
    y=1
    print("-------------------------------")
    x+=1