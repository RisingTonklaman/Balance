while True:
  menuName = input("Plese Enter Menu :")
  if(menuName == "exit"):
    break
  else: