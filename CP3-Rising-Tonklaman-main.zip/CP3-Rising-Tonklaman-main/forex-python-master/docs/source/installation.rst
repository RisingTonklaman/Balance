Installation
============

The recommended way to install the Debug Toolbar is via pip::

    $ pip install forex-python

Install from development branch::

    $ pip install git+https://github.com/MicroPyramid/forex-python.git


.. note::

    forex-python uses requests_ to make API calls.
.. _requests: https://github.com/kennethreitz/requests
